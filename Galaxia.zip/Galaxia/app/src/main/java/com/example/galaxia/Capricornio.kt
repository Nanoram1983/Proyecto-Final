package com.example.galaxia

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Capricornio : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_capricornio)

        val btn: Button = findViewById(R.id.button2)
        btn.setOnClickListener {

            val intent = Intent(this, Sagitario::class.java)
            startActivity(intent)
        }

        val btn2: Button = findViewById(R.id.button3)
        btn2.setOnClickListener {

            val intent = Intent(this, Acuario::class.java)
            startActivity(intent)
        }
    }
}