package com.example.galaxia

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Tauro : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tauro)

        val btn: Button = findViewById(R.id.button2)
        btn.setOnClickListener {

            val intent = Intent(this, Aries::class.java)
            startActivity(intent)
        }

        val btn2: Button = findViewById(R.id.button3)
        btn2.setOnClickListener {

            val intent = Intent(this, Geminis::class.java)
            startActivity(intent)
        }
    }
}